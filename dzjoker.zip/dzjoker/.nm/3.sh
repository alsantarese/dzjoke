cd $HOME/dzjoker/.max/
python2 zz.py
