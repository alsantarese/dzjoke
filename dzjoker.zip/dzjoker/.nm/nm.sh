clear

#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install
cd $HOME/dzjoker/.nm/
clear
echo -e "$red"
toilet -f mono12 -F gay "NMAap"
echo -e $red"["$w"1"$red"]"$w "check the ip"
sleep 0.1
echo -e $red"["$w"2"$red"]"$w "All Devices" $red"                    ["$w"00"$red"]"$red" ExIT"
sleep 0.1
echo -e $red"["$w"3"$red"]"$w "Guess on ip" $red"                    ["$w"99"$red"]"$cyan" BaCk"
sleep 0.1
echo -e "$cyan"
read -p "PleaSe>>>Enter>>>NuMbeR>>> " nm

if [ "$nm" -eq "99"  ]; then
cd /$HOME/dzjoker/
./joker.sh

fi
if [ "$nm" -eq "00" ]; then
clear
exit
fi

ch(){
clear
echo -e "$red"
figlet -f big "CheCkIP"
read -p "{<IP>}=====((?))>>>>" ip
apt $n  nmap -y
clear
nmap $ip
sleep 3
echo -e "$green"
read -p "===========>>PLEASE ENTAR<<============"
cd $HOME/dzjoker/.nm/
./nm.sh
}
if [ "$nm" -eq "1" ]; then
	ch
fi
#######-##5555555
al(){
clear
echo -e "$red"
figlet -f big "Devices""
sleep 0.7
apt $n  nmap -y
clear
nmap -sn 192.168.1.1/24

cd $HOME/dzjoker/.nm/
./nm.sh
}
if [ "$nm" -eq "2" ]; then
        al
fi
#######-##5555555
#######-##5555555

if [ "$nm" -eq "3" ]; then
sh $HOME/dzjoker/.nm/3.sh
fi
#######-##5555555
