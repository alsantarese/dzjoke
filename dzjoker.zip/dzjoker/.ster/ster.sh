
#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install

cd /$HOME/dzjoker/.ster/

clear
echo -e "$green"
figlet  -f big "S Termux"
sleep 1
echo -e $red"["$w"1"$red"]"$reset "S_Tools"
sleep 0.1
echo -e $red"["$w"2"$red"]"$reset "Bashrc"   $red"                    ["$w"00"$red"]"$red" ExIT"
sleep 0.1
echo -e $red"["$w"3"$red"]"$reset "Cowsay"   $red"                    ["$w"99"$red"]"$cyan" BaCk"
sleep 0.1
echo -e $red"["$w"4"$red"]"$reset "Toilet"
sleep 0.1
echo -e $red"["$w"5"$red"]"$reset "w3m"
echo -e "$red"
read -p "Please Enter NuMbeR<<<<H>>>>:~# " st



if [ "$ali" -eq "1" ]; then
         st
fi
if [ "$st" -eq "99"  ]; then
cd /$HOME/dzjoker/
         ./joker.sh

fi
if [ "$st" -eq "00" ]; then
clear
exit
fi
#########
pkp(){
echo -e "$green"
figlet  -f big "S Termux"
sleep 1
pkg $n python && pkg $n perl -y && pkg $n ruby -y && pkg $n proot -y && pkg $n wget -y

pkg $n python2 && pkg $n figlet &&  pkg $n cmatrix -y && pkg $n nano -y
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh
}


if [ "$st" -eq "1"  ]; then
        pkp
fi
#############
bash(){
echo -e "$green"
figlet  -f big "Bashrc Ter.."
sleep 1
cd
git clone https://github.com/alsantarese/bashrc
mv $HOME/bashrc/joker20199 .bashrc

pkg install figlet
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
clear
echo -e "$yellow"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh
}

if [ "$st" -eq "2"  ]; then
        bash
fi
##############
sl(){
echo -e "$blue"
figlet  -f big "st..Cowsay"
sleep 1
apt $n cowsay
clear
echo -e "$blue"
echo "Please Enter Your Name ???????!!"
read  cowsay
clear
cowsay $cowsay
sleep 2
clear
echo -e "$purple"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$st" -eq "3"  ]; then
        sl
fi
#############
iii(){
echo -e "$green"
figlet  -f big "St.. Toilet"
sleep 1
apt $n toilet
clear
echo -e "$green"
echo -e $cyan"Please Enter Your Name:::::"
read toilet
toilet -f mono12 -F gay $toilet
sleep 3
clear
echo -e "$red"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh

}

if [ "$st" -eq "4"  ]; then
        iii
fi
############
fish(){
echo -e "$green"
figlet  -f big "Start w3m"
sleep 1
apt $n w3m
read w3m
w3m $w3m
clear
echo -e "$cyan"
figlet  -f big "Dz JoOkeR"
echo "Please Enter Back<<<"
read back

$back clear
cd /$HOME/dzjoker
./joker.sh
}
if [ "$st" -eq "5"  ]; then
        fish
fi
########################
