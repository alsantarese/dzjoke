clear

#colors
w='\e[97m'
g='\033[1;92m'
r='\033[1;91m'
a='\033[1;94m'
b='\e[1;4m'
cyan='\033[1;36m'
green='\033[1;32m'
red='\033[1;31m'
yellow='\033[1;33m'
blue='\033[1;34m'
purple='\033[1;35m'
reset='\033[0m'
G='\e[110m'
G1='\e[101m'
o='\033[0m'
n=install




cd $HOME/dzjoker/.viros/
toilet -f mono12 -F gay "Virus"
echo -e ""$red"[$reset"1"$red]$green Virus FACEBOOK"
sleep 0.1
echo -e ""$red"[$reset"2"$red]$green Virus WATSUPP" $red"                    ["$w"00"$red"]"$red" ExIT"
sleep 0.1
echo -e ""$red"[$reset"3"$red]$green Virus Instagram" $red"                  ["$w"99"$red"]"$cyan" BaCk"
sleep 0.1
echo -e ""$red"[$reset"4"$red]$green Virus Messenger"
sleep 0.1
echo -e ""$red"[$reset"5"$red]$green Virus VIRS"
echo -e "$red"
read -p "PleASE EnTeaR NumBer>>>>>> " vir

############
vf(){
echo -e "$red"
figlet -f big "VirusF"
sleep 1
cd /$HOME/dzjoker/
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/dzjoker/.viros/Facebook.apk /sdcard/dzjoker
figlet -f big "Done..."
sleep 1
cd /$HOME/dzjoker/.viros/
./.vir.sh
}

if [ "$vir" -eq "1" ]; then
            vf
fi
############
vw(){
echo -e "$red"
figlet -f big "VirusW"
sleep 1
cd /$HOME/dzjoker/
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/dzjoker/.viros/WhatsApp.apk /sdcard/dzjoker
figlet -f big "Done..."
sleep 1
cd /$HOME/dzjoker/.viros/
./.vir.sh
}

if [ "$vir" -eq "2" ]; then
            vw
fi
############
vi(){
echo -e "$red"
figlet -f big "VirusI"
sleep 1
cd /$HOME/dzjoker/
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/dzjoker/.viros/Instagram.apk /sdcard/dzjoker
figlet -f big "Done..."
sleep 1
cd /$HOME/dzjoker/.viros/
./.vir.sh
}

if [ "$vir" -eq "3" ]; then
            vi
fi
############
vi(){
echo -e "$red"
figlet -f big "VirusI"
sleep 1
cd /$HOME/dzjoker/
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/dzjoker/.viros/Instagram.apk /sdcard/dzjoker
figlet -f big "Done..."
sleep 1
cd /$HOME/dzjoker/.viros/
./.vir.sh
}

if [ "$vir" -eq "4" ]; then
            vi
fi
############
vv(){
echo -e "$red"
figlet -f big "VirusV"
sleep 1
cd /$HOME/dzjoker/
chmod +x .bvbv.sh
sh .bvbv.sh
cp $HOME/dzjoker/.viros/virs.apk /sdcard/dzjoker
figlet -f big "Done..."
sleep 1
cd /$HOME/dzjoker/.viros/
./.vir.sh
}

if [ "$vir" -eq "5" ]; then
            vv
fi

#####
if [ "$vir" -eq "99"  ]; then
cd /$HOME/dzjoker/
./joker.sh

fi
if [ "$vir" -eq "00" ]; then
clear
exit
fi
#########
